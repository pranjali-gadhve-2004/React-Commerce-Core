import ProductProvider from "./context/ProductProvider";
import CartProvider from "./context/CardProvider";
import AuthProvider from "./context/AuthProvider";
import OrderProvider from "./context/OrderProvider";
import UIProvider from "./context/UIProvider";

import Home from "./user/Home";

function App() {

  return (
    <UIProvider>
      <AuthProvider>
        <ProductProvider>
          <CardProvider>
            <OrderProvider>

              <Home />

            </OrderProvider>
          </CardProvider>
        </ProductProvider>
      </AuthProvider>
    </UIProvider>
  );
}

export default App;