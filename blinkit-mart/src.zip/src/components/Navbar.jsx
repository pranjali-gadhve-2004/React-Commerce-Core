import { Link } from "react-router-dom";
import { useContext } from "react";

import { CartContext } from "../context/Cardcontext";
import { AuthContext } from "../context/AuthProvider";

function Navbar(){

  const cartData = useContext(CartContext);
  const authData = useContext(AuthContext);

  const totalItems = cartData.totalItems;
  const user = authData.user;
  const logout = authData.logout;

  return(

  <>

    <div    style={{
              padding:"6px 10px",
              background:"black",
              border:"none",
              color:"white",
              display:"flex",
              justifyContent:"space-around",
              alignItems:"center",
              height:"80px",
              width:"100%",
              
             
            }}>
              <img  style={{width:"60px"}}src="https://play-lh.googleusercontent.com/5vcrZX1-Rx6NpuOASKSUWqMpQqbFTiLOZ-IV8CehAP3XycsmaKJvp36BJOxaKhq8TWc" alt="" />
       
      <input type="text" placeholder="enter products name"  style={{height:"40px",width:"30%", borderRadius:"10px"}}/>
      {/* <Link to="/cart"  style={{color:"white" ,textDecoration:"none"}}>
        Cart ({totalItems})
      </Link> */}

      {user == null ? (

        <Link to="/login"  style={{color:"white" ,textDecoration:"none"}}>Login</Link>

      ) : (

        <button onClick={logout}>Logout</button>

      )}
      <p>Nagpur,Maharastra</p>

      {user && user.role === "admin" && (

        <Link to="/admin">Admin</Link>

      )}

    </div>
   <div style={{
  backgroundColor:"gray",
  height:"45px",
  width:"100%",
  display:"flex",
  justifyContent:"space-around",
  alignItems:"center"
}}>

  <Link to="/" style={{color:"white", textDecoration:"none"}}>Home</Link>

  <Link to="/mens" style={{color:"white", textDecoration:"none"}}>Mens</Link>

  <Link to="/womens" style={{color:"white", textDecoration:"none"}}>Womens</Link>

  <Link to="/kids" style={{color:"white", textDecoration:"none"}}>Kids</Link>

  <Link to="/electronics" style={{color:"white", textDecoration:"none"}}>Electronics</Link>

</div>
  </>
    

  );
}

export default Navbar;