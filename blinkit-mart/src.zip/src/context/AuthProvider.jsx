import { createContext, useState } from "react";

export const AuthContext = createContext();

export function AuthProvider(props) {

  const [user, setUser] = useState(null);

  function login(name) {
    setUser({ name: name, role: "user" });
  }

  function logout() {
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{
      user,
      login,
      logout
    }}>
      {props.children}
    </AuthContext.Provider>
  );
}

export default AuthProvider;