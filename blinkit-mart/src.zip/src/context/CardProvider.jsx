import { createContext, useState, useEffect } from "react";

export const CartContext = createContext();

function CartProvider(props) {

  const [cart, setCart] = useState([]);

  // 🔥 LOAD FROM LOCALSTORAGE
  useEffect(function () {

    let stored = localStorage.getItem("cart");

    if (stored) {
      setCart(JSON.parse(stored));
    }

  }, []);

  // 🔥 SAVE TO LOCALSTORAGE
  useEffect(function () {
    localStorage.setItem("cart", JSON.stringify(cart));
  }, [cart]);

  // 🔥 ADD ITEM
  function addItem(product) {

    let exists = false;
    let updated = [];

    for (let i = 0; i < cart.length; i++) {

      let item = cart[i];

      if (item.id === product.id) {
        item.qty = item.qty + 1;
        exists = true;
      }

      updated.push(item);
    }

    if (!exists) {
      updated.push({ ...product, qty: 1 });
    }

    setCart(updated);
  }

  // 🔥 REMOVE ITEM
  function removeItem(id) {

    let result = [];

    for (let i = 0; i < cart.length; i++) {
      if (cart[i].id !== id) {
        result.push(cart[i]);
      }
    }

    setCart(result);
  }

  // 🔥 TOTAL PRICE
  function getTotal() {

    let total = 0;

    for (let i = 0; i < cart.length; i++) {
      total = total + (cart[i].price * cart[i].qty);
    }

    return total;
  }

  return (
    <CartContext.Provider value={{
      cart,
      addItem,
      removeItem,
      total: getTotal()
    }}>
      {props.children}
    </CartContext.Provider>
  );
}

export default CartProvider;