import { createContext, useState } from "react";

export const OrderContext = createContext();

function OrderProvider(props) {

  const [orders, setOrders] = useState([]);

  function placeOrder(cart, total) {

    let newOrder = {
      items: cart,
      total: total,
      status: "Pending",
      date: new Date().toLocaleString()
    };

    setOrders(function(prev) {
      return [...prev, newOrder];
    });
  }

  return (
    <OrderContext.Provider value={{
      orders,
      placeOrder
    }}>
      {props.children}
    </OrderContext.Provider>
  );
}

export default OrderProvider;