import { createContext, useState, useEffect } from "react";

export const ProductContext = createContext();

function ProductProvider(props) {

  const [products, setProducts] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [category, setCategory] = useState("");

  useEffect(function () {

    fetch("http://localhost:3000")
      .then(function (res) { return res.json(); })
      .then(function (data) {

        let all = [];

        for (let key in data) {
          for (let i = 0; i < data[key].length; i++) {

            let item = data[key][i];

            all.push({
              id: item.id,
              name: item.name,
              price: item.price,
              image: item.image,
              category: key
            });
          }
        }

        setProducts(all);
        setFiltered(all);
      });

  }, []);

  // 🔥 FILTER (LONG WAY)
  function filterByCategory(cat) {

    setCategory(cat);

    let result = [];

    for (let i = 0; i < products.length; i++) {

      let p = products[i];

      if (cat === "") {
        result.push(p);
      } else {
        if (p.category === cat) {
          result.push(p);
        }
      }
    }

    setFiltered(result);
  }

  return (
    <ProductContext.Provider value={{
      products: filtered,
      filterByCategory
    }}>
      {props.children}
    </ProductContext.Provider>
  );
}

export default ProductProvider;