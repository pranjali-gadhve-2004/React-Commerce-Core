import { createContext, useState } from "react";

export const UIContext = createContext();

function UIProvider(props) {

  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  function showMessage(msg) {
    setMessage(msg);

    setTimeout(function () {
      setMessage("");
    }, 2000);
  }

  return (
    <UIContext.Provider value={{
      loading,
      setLoading,
      message,
      showMessage
    }}>
      {props.children}
    </UIContext.Provider>
  );
}

export default UIProvider;