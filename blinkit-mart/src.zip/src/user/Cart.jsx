function Cart(props) {

  return (
    <div style={{
      padding: "20px"
    }}>

      <h2>Your Cart</h2>

      {props.cart.map(function(item){

        return (
          <div key={item.id} style={{
            display: "flex",
            justifyContent: "space-between",
            borderBottom: "1px solid #ccc",
            marginBottom: "10px",
            paddingBottom: "10px"
          }}>

            <span>{item.name}</span>
            <span>₹{item.price}</span>

            <button onClick={function(){
              props.removeFromCart(item.id);
            }}>
              Remove
            </button>

          </div>
        );
      })}

    </div>
  );
}

export default Cart;