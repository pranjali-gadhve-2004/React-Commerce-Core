import { useContext } from "react";
import { ProductContext } from "../context/ProductProvider";
import { CartContext } from "../context/CardProvider";

function Home() {

  const { products, filterByCategory } = useContext(ProductContext);
  const { addItem } = useContext(CartContext);

  return (
    <div>

      {/* FILTER */}
      <div style={{ padding: "20px" }}>
        <button onClick={() => filterByCategory("")}>All</button>
        <button onClick={() => filterByCategory("mens")}>Mens</button>
        <button onClick={() => filterByCategory("womens")}>Womens</button>
      </div>

      {/* PRODUCTS */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill,200px)",
        gap: "20px"
      }}>

        {products.map(function(item){

          return (
            <div key={item.id} style={{
              border: "1px solid #ccc",
              padding: "10px"
            }}>

              <img src={item.image} style={{ width: "100%" }} />

              <h3>{item.name}</h3>
              <p>₹{item.price}</p>

              <button onClick={() => addItem(item)}>
                Add to Cart
              </button>

            </div>
          );
        })}

      </div>

    </div>
  );
}

export default Home;