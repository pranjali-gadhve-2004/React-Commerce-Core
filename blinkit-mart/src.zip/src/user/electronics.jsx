import React from 'react'

export default function electronics() {
  return (
  <div>
    <h2>Products</h2>

      <input
        placeholder="Search"
        onChange={(e)=>setSearch(e.target.value)}
      />
  
  </div>
)}
